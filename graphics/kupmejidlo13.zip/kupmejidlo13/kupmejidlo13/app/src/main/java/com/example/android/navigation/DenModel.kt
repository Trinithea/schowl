package com.example.android.navigation

// 'den' se skládá z názvu, tří jídel a ingrediencí k patřičným jídlům
// pokud tedy v komentářích narazíte na slovo den, znamená toto
class DenModel(val den: String, val sn: String, val ob: String,  val ve: String, val ingr_sn: String, val ingr_ob : String, val ingr_ve : String)